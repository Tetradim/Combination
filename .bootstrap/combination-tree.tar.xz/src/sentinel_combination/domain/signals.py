from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from .brackets import TakeProfitTarget, TrailingRule
from .enums import OrderType, Side, TimeInForce


@dataclass(frozen=True)
class TradeSignal:
    signal_id: str
    instrument_id: str
    side: Side
    strategy_id: str
    stop_price: Decimal
    quantity: Decimal | None = None
    risk_amount: Decimal | None = None
    order_type: OrderType = OrderType.MARKET
    time_in_force: TimeInForce = TimeInForce.GTC
    limit_price: Decimal | None = None
    targets: tuple[TakeProfitTarget, ...] = ()
    trailing: TrailingRule | None = None
    net_cost_after_target_index: int | None = None

    def __post_init__(self) -> None:
        for name in ("signal_id", "instrument_id", "strategy_id"):
            if not getattr(self, name).strip():
                raise ValueError(f"{name} is required")
        if self.stop_price <= 0:
            raise ValueError("stop_price must be positive")
        if (self.quantity is None) == (self.risk_amount is None):
            raise ValueError("exactly one of quantity or risk_amount is required")
        if self.quantity is not None and self.quantity <= 0:
            raise ValueError("quantity must be positive")
        if self.risk_amount is not None and self.risk_amount <= 0:
            raise ValueError("risk_amount must be positive")
        if self.order_type in {OrderType.LIMIT, OrderType.STOP_LIMIT} and self.limit_price is None:
            raise ValueError("limit_price is required")
