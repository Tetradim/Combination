from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime
from decimal import Decimal

from .enums import Side


@dataclass(frozen=True)
class Position:
    account_id: str
    instrument_id: str
    quantity: Decimal = Decimal("0")
    average_entry_price: Decimal = Decimal("0")
    realized_pnl: Decimal = Decimal("0")
    fees_paid: Decimal = Decimal("0")
    updated_at: datetime | None = None

    def apply_fill(self, *, side: Side, quantity: Decimal, price: Decimal, fee: Decimal, multiplier: Decimal, occurred_at: datetime) -> "Position":
        if quantity <= 0 or price <= 0 or fee < 0 or multiplier <= 0:
            raise ValueError("invalid fill values")
        signed = quantity * side.sign
        old = self.quantity
        new = old + signed
        avg = self.average_entry_price
        realized = self.realized_pnl
        if old == 0 or (old > 0 and signed > 0) or (old < 0 and signed < 0):
            total = abs(old) + quantity
            avg = ((abs(old) * avg) + quantity * price) / total
        else:
            closing = min(abs(old), quantity)
            direction = Decimal("1") if old > 0 else Decimal("-1")
            realized += (price - avg) * closing * direction * multiplier
            if new == 0:
                avg = Decimal("0")
            elif (old > 0 > new) or (old < 0 < new):
                avg = price
        return replace(self, quantity=new, average_entry_price=avg, realized_pnl=realized - fee, fees_paid=self.fees_paid + fee, updated_at=occurred_at)
