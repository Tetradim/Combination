from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from .enums import BracketStatus, OrderType, Side, TimeInForce
from .events import utc_now
from .instruments import Instrument
from .orders import OrderIntent


def _fraction(value: Decimal) -> None:
    if value <= 0 or value > 1:
        raise ValueError("fraction must be greater than zero and no more than one")


@dataclass(frozen=True)
class ProtectiveStop:
    trigger_price: Decimal
    net_cost_after_target_index: int | None = None

    def __post_init__(self) -> None:
        if self.trigger_price <= 0:
            raise ValueError("protective stop must be positive")
        if self.net_cost_after_target_index is not None and self.net_cost_after_target_index < 0:
            raise ValueError("target index cannot be negative")


@dataclass(frozen=True)
class TakeProfitTarget:
    trigger_price: Decimal
    close_fraction: Decimal

    def __post_init__(self) -> None:
        if self.trigger_price <= 0:
            raise ValueError("target price must be positive")
        _fraction(self.close_fraction)


@dataclass(frozen=True)
class TrailingRule:
    close_fraction: Decimal
    distance_pct: Decimal | None = None
    distance_amount: Decimal | None = None
    activation_price: Decimal | None = None
    activate_after_target_index: int | None = None
    ratchet_step: Decimal | None = None

    def __post_init__(self) -> None:
        _fraction(self.close_fraction)
        if (self.distance_pct is None) == (self.distance_amount is None):
            raise ValueError("exactly one trailing distance is required")
        for value in (self.distance_pct, self.distance_amount, self.activation_price, self.ratchet_step):
            if value is not None and value <= 0:
                raise ValueError("trailing values must be positive")
        if self.activate_after_target_index is not None and self.activate_after_target_index < 0:
            raise ValueError("target index cannot be negative")


@dataclass(frozen=True)
class BracketPlan:
    bracket_id: str
    schema_version: int
    semantics_version: str
    account_id: str
    instrument_id: str
    strategy_id: str
    entry_order_id: str
    entry_side: Side
    protective_stop: ProtectiveStop
    take_profit_targets: tuple[TakeProfitTarget, ...] = ()
    trailing_rule: TrailingRule | None = None

    def __post_init__(self) -> None:
        for name in ("bracket_id", "semantics_version", "account_id", "instrument_id", "strategy_id", "entry_order_id"):
            if not getattr(self, name).strip():
                raise ValueError(f"{name} is required")
        if self.schema_version <= 0:
            raise ValueError("schema_version must be positive")
        allocation=sum((x.close_fraction for x in self.take_profit_targets), Decimal("0"))
        if self.trailing_rule is not None:
            allocation += self.trailing_rule.close_fraction
        if allocation > 1:
            raise ValueError("target and trailing allocation exceeds confirmed quantity")
        idx = self.protective_stop.net_cost_after_target_index
        if idx is not None and idx >= len(self.take_profit_targets):
            raise ValueError("net-cost target index is missing")

    def validate_prices(self, entry_price: Decimal) -> None:
        stop = self.protective_stop.trigger_price
        if self.entry_side is Side.BUY:
            if stop >= entry_price or any(x.trigger_price <= entry_price for x in self.take_profit_targets):
                raise ValueError("invalid long bracket prices")
            if any(b.trigger_price <= a.trigger_price for a, b in zip(self.take_profit_targets, self.take_profit_targets[1:])):
                raise ValueError("long targets must increase")
        else:
            if stop <= entry_price or any(x.trigger_price >= entry_price for x in self.take_profit_targets):
                raise ValueError("invalid short bracket prices")
            if any(b.trigger_price >= a.trigger_price for a, b in zip(self.take_profit_targets, self.take_profit_targets[1:])):
                raise ValueError("short targets must decrease")

    def initial_exit_intents(self, *, instrument: Instrument, confirmed_quantity: Decimal, average_entry_price: Decimal) -> tuple[OrderIntent, ...]:
        if instrument.instrument_id != self.instrument_id:
            raise ValueError("instrument mismatch")
        self.validate_prices(average_entry_price)
        qty = instrument.quantize_quantity_down(confirmed_quantity)
        if qty <= 0:
            raise ValueError("confirmed quantity rounds to zero")
        side = self.entry_side.opposite
        intents: list[OrderIntent] = [OrderIntent(
            client_order_id=f"{self.bracket_id}:stop:0", account_id=self.account_id,
            instrument_id=self.instrument_id, side=side, quantity=qty,
            order_type=OrderType.STOP, stop_price=instrument.quantize_price(self.protective_stop.trigger_price),
            reduce_only=True, strategy_id=self.strategy_id, bracket_id=self.bracket_id,
            parent_order_id=self.entry_order_id, oca_group_id=f"{self.bracket_id}:exits",
            time_in_force=TimeInForce.GTC, created_at=utc_now())]
        for i, target in enumerate(self.take_profit_targets):
            target_qty = instrument.quantize_quantity_down(qty * target.close_fraction)
            if target_qty <= 0:
                raise ValueError(f"target {i} rounds to zero")
            intents.append(OrderIntent(
                client_order_id=f"{self.bracket_id}:tp:{i}:0", account_id=self.account_id,
                instrument_id=self.instrument_id, side=side, quantity=target_qty,
                order_type=OrderType.LIMIT, limit_price=instrument.quantize_price(target.trigger_price),
                reduce_only=True, strategy_id=self.strategy_id, bracket_id=self.bracket_id,
                parent_order_id=self.entry_order_id, oca_group_id=f"{self.bracket_id}:exits",
                time_in_force=TimeInForce.GTC, created_at=utc_now()))
        return tuple(intents)

    def compile_slices(self, *, instrument: Instrument, confirmed_quantity: Decimal, average_entry_price: Decimal, generation: int) -> tuple["BracketSlice", ...]:
        if instrument.instrument_id != self.instrument_id:
            raise ValueError("instrument mismatch")
        self.validate_prices(average_entry_price)
        total_fraction=sum((x.close_fraction for x in self.take_profit_targets), Decimal("0"))
        if self.trailing_rule is not None:
            total_fraction += self.trailing_rule.close_fraction
        if total_fraction > 1:
            raise ValueError("target and trailing allocations exceed confirmed quantity")
        total=instrument.quantize_quantity_down(confirmed_quantity)
        if total <= 0:
            raise ValueError("confirmed quantity rounds to zero")
        side=self.entry_side.opposite; allocated=Decimal("0"); slices=[]
        for index,target in enumerate(self.take_profit_targets):
            qty=instrument.quantize_quantity_down(total*target.close_fraction)
            if qty<=0: raise ValueError(f"target {index} rounds to zero")
            allocated += qty; group=f"{self.bracket_id}:g{generation}:tp{index}"
            stop=OrderIntent(client_order_id=f"{group}:stop",account_id=self.account_id,instrument_id=self.instrument_id,side=side,quantity=qty,order_type=OrderType.STOP,stop_price=instrument.quantize_price(self.protective_stop.trigger_price),reduce_only=True,strategy_id=self.strategy_id,bracket_id=self.bracket_id,parent_order_id=self.entry_order_id,oca_group_id=group,time_in_force=TimeInForce.GTC,created_at=utc_now())
            tp=OrderIntent(client_order_id=f"{group}:target",account_id=self.account_id,instrument_id=self.instrument_id,side=side,quantity=qty,order_type=OrderType.LIMIT,limit_price=instrument.quantize_price(target.trigger_price),reduce_only=True,strategy_id=self.strategy_id,bracket_id=self.bracket_id,parent_order_id=self.entry_order_id,oca_group_id=group,time_in_force=TimeInForce.GTC,created_at=utc_now())
            slices.append(BracketSlice(group,qty,stop,tp,False))
        if self.trailing_rule is not None:
            qty=instrument.quantize_quantity_down(total*self.trailing_rule.close_fraction)
            if qty<=0: raise ValueError("trailing allocation rounds to zero")
            allocated += qty; group=f"{self.bracket_id}:g{generation}:trail"
            stop=OrderIntent(client_order_id=f"{group}:stop",account_id=self.account_id,instrument_id=self.instrument_id,side=side,quantity=qty,order_type=OrderType.STOP,stop_price=instrument.quantize_price(self.protective_stop.trigger_price),reduce_only=True,strategy_id=self.strategy_id,bracket_id=self.bracket_id,parent_order_id=self.entry_order_id,oca_group_id=group,time_in_force=TimeInForce.GTC,created_at=utc_now())
            slices.append(BracketSlice(group,qty,stop,None,True))
        residual=instrument.quantize_quantity_down(total-allocated)
        if residual>0:
            group=f"{self.bracket_id}:g{generation}:residual"
            stop=OrderIntent(client_order_id=f"{group}:stop",account_id=self.account_id,instrument_id=self.instrument_id,side=side,quantity=residual,order_type=OrderType.STOP,stop_price=instrument.quantize_price(self.protective_stop.trigger_price),reduce_only=True,strategy_id=self.strategy_id,bracket_id=self.bracket_id,parent_order_id=self.entry_order_id,oca_group_id=group,time_in_force=TimeInForce.GTC,created_at=utc_now())
            slices.append(BracketSlice(group,residual,stop,None,False))
        return tuple(slices)


@dataclass(frozen=True)
class BracketSlice:
    slice_id: str
    quantity: Decimal
    stop_intent: OrderIntent
    target_intent: OrderIntent | None = None
    trailing: bool = False


@dataclass(frozen=True)
class BracketState:
    bracket_id: str
    status: BracketStatus = BracketStatus.PENDING_ENTRY
    confirmed_entry_quantity: Decimal = Decimal("0")
    average_entry_price: Decimal | None = None
    closed_quantity: Decimal = Decimal("0")
    completed_targets: tuple[int, ...] = ()
    high_water: Decimal | None = None
    low_water: Decimal | None = None
    active_order_ids: tuple[str, ...] = ()
    pending_replacements: tuple[str, ...] = ()
    generation: int = 0

    @property
    def remaining_quantity(self) -> Decimal:
        return max(Decimal("0"), self.confirmed_entry_quantity - self.closed_quantity)
