from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ReadinessSnapshot:
    broker_connected: bool
    authenticated: bool
    account_fresh: bool
    market_data_fresh: bool
    positions_reconciled: bool
    orders_reconciled: bool
    kill_switch_clear: bool
    persistence_healthy: bool
    order_stream_healthy: bool
    buying_power_available: bool
    instrument_tradeable: bool
    protective_order_supported: bool
    activation_authorized: bool
    reasons: tuple[str, ...] = ()

    @property
    def ready_for_entry(self) -> bool:
        return all((
            self.broker_connected,
            self.authenticated,
            self.account_fresh,
            self.market_data_fresh,
            self.positions_reconciled,
            self.orders_reconciled,
            self.kill_switch_clear,
            self.persistence_healthy,
            self.order_stream_healthy,
            self.buying_power_available,
            self.instrument_tradeable,
            self.protective_order_supported,
            self.activation_authorized,
        )) and not self.reasons

    @property
    def ready_for_reduction(self) -> bool:
        return all((
            self.broker_connected,
            self.authenticated,
            self.positions_reconciled,
            self.persistence_healthy,
        ))
