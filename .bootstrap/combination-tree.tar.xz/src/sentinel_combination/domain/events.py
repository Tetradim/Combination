from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping
from uuid import uuid4


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class EventEnvelope:
    event_type: str
    source: str
    occurred_at: datetime
    event_id: str = field(default_factory=lambda: str(uuid4()))
    received_at: datetime = field(default_factory=utc_now)
    account_id: str | None = None
    instrument_id: str | None = None
    order_id: str | None = None
    bracket_id: str | None = None
    causation_id: str | None = None
    correlation_id: str | None = None
    schema_version: int = 1
    payload: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.event_type.strip() or not self.source.strip():
            raise ValueError("event_type and source are required")
        if self.occurred_at.tzinfo is None or self.received_at.tzinfo is None:
            raise ValueError("event timestamps must be timezone-aware")
        if self.schema_version <= 0:
            raise ValueError("schema_version must be positive")
