from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal


@dataclass(frozen=True)
class RiskPolicy:
    max_order_notional: Decimal
    max_position_notional: Decimal
    max_spread_pct: Decimal
    max_daily_loss: Decimal
    allow_short_entries: bool = False
    require_protective_stop: bool = True
    max_orders_per_minute: int = 30
    max_open_orders: int = 100

    def __post_init__(self) -> None:
        for value in (
            self.max_order_notional,
            self.max_position_notional,
            self.max_spread_pct,
            self.max_daily_loss,
        ):
            if value < 0:
                raise ValueError("risk limits cannot be negative")
        if self.max_orders_per_minute <= 0:
            raise ValueError("max_orders_per_minute must be positive")
        if self.max_open_orders <= 0:
            raise ValueError("max_open_orders must be positive")


@dataclass(frozen=True)
class RiskDecision:
    approved: bool
    reasons: tuple[str, ...] = ()
