from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .brackets import BracketPlan
from .enums import ReversalStatus
from .orders import OrderIntent


@dataclass(frozen=True)
class ReversalPlan:
    reversal_id: str
    account_id: str
    instrument_id: str
    flatten_order_id: str
    entry_intent: OrderIntent
    bracket_plan: BracketPlan
    created_at: datetime
    status: ReversalStatus = ReversalStatus.FLATTENING
    reason: str = ""

    def __post_init__(self) -> None:
        for name in (
            "reversal_id",
            "account_id",
            "instrument_id",
            "flatten_order_id",
        ):
            if not getattr(self, name).strip():
                raise ValueError(f"{name} is required")
        if self.created_at.tzinfo is None:
            raise ValueError("created_at must be timezone-aware")
        if self.entry_intent.account_id != self.account_id:
            raise ValueError("entry account mismatch")
        if self.entry_intent.instrument_id != self.instrument_id:
            raise ValueError("entry instrument mismatch")
        if self.bracket_plan.entry_order_id != self.entry_intent.client_order_id:
            raise ValueError("bracket entry order mismatch")
