from __future__ import annotations

from enum import Enum


class AssetClass(str, Enum):
    EQUITY = "equity"
    CRYPTO_SPOT = "crypto_spot"
    CRYPTO_PERPETUAL = "crypto_perpetual"
    LISTED_FUTURE = "listed_future"


class Side(str, Enum):
    BUY = "buy"
    SELL = "sell"

    @property
    def sign(self) -> int:
        return 1 if self is Side.BUY else -1

    @property
    def opposite(self) -> "Side":
        return Side.SELL if self is Side.BUY else Side.BUY


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LIMIT = "stop_limit"
    TRAILING_STOP = "trailing_stop"


class TimeInForce(str, Enum):
    DAY = "day"
    GTC = "gtc"
    IOC = "ioc"
    FOK = "fok"


class OrderStatus(str, Enum):
    PLANNED = "planned"
    RISK_APPROVED = "risk_approved"
    SUBMITTING = "submitting"
    SUBMITTED = "submitted"
    ACKNOWLEDGED = "acknowledged"
    WORKING = "working"
    PARTIALLY_FILLED = "partially_filled"
    PENDING_CANCEL = "pending_cancel"
    CANCELED = "canceled"
    FILLED = "filled"
    REJECTED = "rejected"
    EXPIRED = "expired"
    RECONCILIATION_REQUIRED = "reconciliation_required"

    @property
    def terminal(self) -> bool:
        return self in {self.CANCELED, self.FILLED, self.REJECTED, self.EXPIRED}

    @property
    def working(self) -> bool:
        return self in {
            self.SUBMITTED, self.ACKNOWLEDGED, self.WORKING,
            self.PARTIALLY_FILLED, self.PENDING_CANCEL,
            self.RECONCILIATION_REQUIRED,
        }


class OrderUpdateType(str, Enum):
    ACKNOWLEDGED = "acknowledged"
    WORKING = "working"
    PARTIAL_FILL = "partial_fill"
    FILL = "fill"
    CANCELED = "canceled"
    REJECTED = "rejected"
    EXPIRED = "expired"


class KillSwitchLevel(str, Enum):
    CLEAR = "clear"
    PAUSE_ENTRIES = "pause_entries"
    CANCEL_WORKING = "cancel_working"
    FLATTEN_AND_HALT = "flatten_and_halt"


class BracketStatus(str, Enum):
    PENDING_ENTRY = "pending_entry"
    ACTIVE = "active"
    CLOSING = "closing"
    CLOSED = "closed"
    RECONCILIATION_REQUIRED = "reconciliation_required"


class ReversalStatus(str, Enum):
    FLATTENING = "flattening"
    OPENING = "opening"
    COMPLETE = "complete"
    FAILED = "failed"
