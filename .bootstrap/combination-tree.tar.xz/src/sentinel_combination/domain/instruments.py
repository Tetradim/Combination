from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP

from .enums import AssetClass


@dataclass(frozen=True)
class Instrument:
    instrument_id: str
    broker_symbol: str
    asset_class: AssetClass
    venue: str
    price_increment: Decimal
    quantity_increment: Decimal
    minimum_quantity: Decimal
    minimum_notional: Decimal
    contract_multiplier: Decimal = Decimal("1")
    settlement_currency: str = "USD"
    expiry: date | None = None
    first_notice: date | None = None
    last_trade: date | None = None
    last_safe_trade: date | None = None

    def __post_init__(self) -> None:
        for name in ("instrument_id", "broker_symbol", "venue", "settlement_currency"):
            if not getattr(self, name).strip():
                raise ValueError(f"{name} is required")
        for name in ("price_increment", "quantity_increment", "minimum_quantity", "contract_multiplier"):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive")
        if self.minimum_notional < 0:
            raise ValueError("minimum_notional cannot be negative")
        dates = [d for d in (self.first_notice, self.last_safe_trade, self.last_trade, self.expiry) if d]
        if dates != sorted(dates):
            raise ValueError("contract dates must be chronological")

    def quantize_price(self, price: Decimal) -> Decimal:
        if price <= 0:
            raise ValueError("price must be positive")
        steps = (price / self.price_increment).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        return steps * self.price_increment

    def quantize_quantity_down(self, quantity: Decimal) -> Decimal:
        if quantity < 0:
            raise ValueError("quantity cannot be negative")
        steps = (quantity / self.quantity_increment).quantize(Decimal("1"), rounding=ROUND_DOWN)
        return steps * self.quantity_increment

    def validate_order(self, *, quantity: Decimal, reference_price: Decimal, price: Decimal | None = None) -> None:
        if quantity < self.minimum_quantity:
            raise ValueError("quantity is below instrument minimum")
        if self.quantize_quantity_down(quantity) != quantity:
            raise ValueError("quantity is not aligned to instrument increment")
        if price is not None and self.quantize_price(price) != price:
            raise ValueError("price is not aligned to instrument increment")
        notional = quantity * reference_price * self.contract_multiplier
        if notional < self.minimum_notional:
            raise ValueError("order notional is below instrument minimum")

    def tradeable_on(self, day: date) -> bool:
        return self.last_safe_trade is None or day <= self.last_safe_trade
